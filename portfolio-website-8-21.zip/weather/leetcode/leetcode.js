/**
 * @param {number[]} nums
 * @param {number} target
 * @return {number[]}
 */
var twoSum = function(nums, target) {   
    for (i=0;i<nums.length;i++) {
        for (e = 1;e<nums.length;e++) {
            if(nums[i] + nums[e] == target) {
                if(i != e) {
                    return [i,e];
                }
            }
        }
    }
};