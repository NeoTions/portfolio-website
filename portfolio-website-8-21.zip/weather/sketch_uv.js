function setup() {
    let canvas = createCanvas(400, 200);

    canvas.parent("uv_index");
    
    sw = width/10;
    strokeWeight(sw);
    strokeCap(SQUARE);
    textAlign(CENTER);
    textSize(width/4);
  }
  
  
  function draw() {
    background(255,255,255,0);
    
    stroke(33, 219, 0);

    line(0,height,width*0.2,height);
    
    stroke(227, 227,0);
    line(width*0.2,height,width*0.4,height);
    
    stroke(227, 106, 0);
    line(width*0.4,height,width*0.6,height);
    
    stroke(227, 0, 0);
    line(width*0.6,height,width*0.8,height);
    
    stroke(117, 0, 227);
    line(width*0.8,height,width,height);
    
    stroke(255);
    
    place = width*0.10;
    
    line(place,height,place+10,height)
    
    fill(33, 219, 0);
    
    noStroke();
    text("3.6",width/2,height/1.75);

  }